package com.example.proyectodsm941

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        var tologin_ir = findViewById<TextView>(R.id.to_login)
        tologin_ir.setOnClickListener {
            ToLogin_IR()
        }
    }

    private fun ToLogin_IR(){
        var i = Intent(this, MainActivity::class.java)
        startActivity(i)
    }
}