package com.example.proyectodsm941

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.proyectodsm941.util.PreferenceHelper
import com.example.proyectodsm941.util.PreferenceHelper.set

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)


        var exit_to_login_ir = findViewById<TextView>(R.id.exit_to_login)
        exit_to_login_ir.setOnClickListener {
            clearSessionPreferens()
            ExitToLogin_IR()
        }
    }

    private fun ExitToLogin_IR(){
        var i = Intent(this, MainActivity::class.java)
        startActivity(i)
        finish()
    }

    private  fun clearSessionPreferens() {
        val preferences = PreferenceHelper.defaultPrefs(this)
        preferences["session"] = false

    }
}