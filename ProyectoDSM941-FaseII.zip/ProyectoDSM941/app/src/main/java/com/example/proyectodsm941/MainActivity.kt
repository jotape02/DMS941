package com.example.proyectodsm941

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.example.proyectodsm941.util.PreferenceHelper
import com.example.proyectodsm941.util.PreferenceHelper.get
import com.example.proyectodsm941.util.PreferenceHelper.set

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        var SplashView = installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        SplashView.setKeepOnScreenCondition(){true}
        var i =  Intent(this, LoginActivity::class.java)
        startActivity(i)
        finish()


    }

}