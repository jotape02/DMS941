package com.example.proyectodsm941

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.example.proyectodsm941.util.PreferenceHelper
import com.example.proyectodsm941.util.PreferenceHelper.get
import com.example.proyectodsm941.util.PreferenceHelper.set

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


/* Crear la Session y se va al menu*/
        var preference = PreferenceHelper.defaultPrefs(this)
        if (preference["session", false])
            LoginToMenu_IR()


        /*Ir a view Restistro*/
        var toregisto_ir = findViewById<TextView>(R.id.to_registro)
        toregisto_ir.setOnClickListener {
            ToReistro_IR()
        }

        /*ir view Menu*/
        var loginToMenu_ir = findViewById<TextView>(R.id.login_to_menu)
        loginToMenu_ir.setOnClickListener {
            LoginToMenu_IR()
        }
    }
/*Funcion de para ir a view registro*/
    private fun ToReistro_IR (){
        var i = Intent(this, RegisterActivity::class.java)
        startActivity(i)
    }

    /*Funcion de para ir a view menu*/
    private fun LoginToMenu_IR (){
        var i = Intent(this, MenuActivity::class.java)
        createsessionpreferens()
        startActivity(i)
        finish()
    }
    /*crear ssesion ir a view resitro*/
    private fun createsessionpreferens(){

        var preference = PreferenceHelper.defaultPrefs(this)
        preference["session"] = true
    }
}